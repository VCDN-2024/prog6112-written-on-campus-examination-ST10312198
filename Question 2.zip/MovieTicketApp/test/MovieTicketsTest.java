/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Talha
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets movieTickets = new MovieTickets();
        int numberOfTickets = 3;
        double ticketPrice = 100.0;
        double expectedTotalPrice = 342.0; // Includes 14% VAT
        assertEquals(expectedTotalPrice, movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice), 0.01);
    }

    @Test
    public void ValidateData_ReturnsTrueForValidData() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData validData = new MovieTicketData("Napoleon", 3, 100.0);
        assertTrue(movieTickets.ValidateData(validData));
    }

    @Test
    public void ValidateData_ReturnsFalseForInvalidTicketCount() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData invalidData = new MovieTicketData("Napoleon", 0, 100.0);
        assertFalse(movieTickets.ValidateData(invalidData));
    }

    @Test
    public void ValidateData_ReturnsFalseForInvalidTicketPrice() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData invalidData = new MovieTicketData("Napoleon", 3, -10.0);
        assertFalse(movieTickets.ValidateData(invalidData));
    }

    @Test
    public void ValidateData_ReturnsFalseForEmptyMovieName() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData invalidData = new MovieTicketData("", 3, 100.0);
        assertFalse(movieTickets.ValidateData(invalidData));
    }
}
