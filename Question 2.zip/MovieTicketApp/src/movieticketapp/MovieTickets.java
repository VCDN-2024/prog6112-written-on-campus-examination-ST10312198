/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Talha
 */
public class MovieTickets implements IMovieTickets {
    private static final double VAT_RATE = 0.14;

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double totalWithoutVAT = numberOfTickets * ticketPrice;
        return totalWithoutVAT + (totalWithoutVAT * VAT_RATE);
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().isEmpty()) {
            return false;
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false;
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return false;
        }
        return true;
    }
}
