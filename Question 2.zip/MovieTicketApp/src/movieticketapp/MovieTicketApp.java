/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Talha
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTicketApp extends JFrame {
    private JComboBox<String> movieComboBox;
    private JTextField ticketPriceField;
    private JTextField numberOfTicketsField;
    private JTextArea reportArea;
    private MovieTickets movieTickets;
    private JPanel panel;

    public MovieTicketApp() {
        setTitle("Movie Tickets");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        movieTickets = new MovieTickets();

        // Initialize panel
        panel = new JPanel();

        // Setup Combo Box
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        ticketPriceField = new JTextField(10);
        numberOfTicketsField = new JTextField(10);
        reportArea = new JTextArea(10, 30);
        reportArea.setEditable(false);

        // Setup Menu
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(new ProcessAction());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearFields());

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // Add components to the panel
        panel.add(new JLabel("Movie:"));
        panel.add(movieComboBox);
        panel.add(new JLabel("Number of Tickets:"));
        panel.add(numberOfTicketsField);
        panel.add(new JLabel("Ticket Price:"));
        panel.add(ticketPriceField);
        panel.add(new JLabel("Ticket Report:"));
        panel.add(new JScrollPane(reportArea));

        // Add panel to the frame
        add(panel);
    }

    private class ProcessAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String movieName = (String) movieComboBox.getSelectedItem();
            int numberOfTickets;
            double ticketPrice;

            try {
                numberOfTickets = Integer.parseInt(numberOfTicketsField.getText().trim());
                ticketPrice = Double.parseDouble(ticketPriceField.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for tickets and price.");
                return;
            }

            MovieTicketData data = new MovieTicketData(movieName, numberOfTickets, ticketPrice);

            if (!movieTickets.ValidateData(data)) {
                JOptionPane.showMessageDialog(null, "Invalid data. Please check your inputs.");
                return;
            }

            // Calculate the total ticket price including VAT
            double totalTicketPrice = movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);

            // Generate the report text
            String report = String.format(
                "MOVIE TICKET REPORT\n" +
                "-------------------\n" +
                "Movie Name: %s\n" +
                "Ticket Price: R %.2f\n" +
                "Number of Tickets: %d\n" +
                "Total Ticket Price: R %.2f\n",
                movieName, ticketPrice, numberOfTickets, totalTicketPrice
            );

            reportArea.setText(report);
            saveReportToFile(report);
        }

        private void saveReportToFile(String report) {
            try (FileWriter writer = new FileWriter("report.txt")) {
                writer.write(report);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error saving report to file.");
            }
        }
    }

    private void clearFields() {
        movieComboBox.setSelectedIndex(0);
        ticketPriceField.setText("");
        numberOfTicketsField.setText("");
        reportArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MovieTicketApp().setVisible(true);
        });
    }
}

//----Code Attribution----//
//(Movie Ticket Booking..)//
// Available at: ( https://youtube.com/playlist?list=PLQMGOpcYnHOV1u0J9OBVwvdQm79PIsbxi&si=wUVy-I2nKHt5zhPk )//
//Accessed on: 12 November 2024)//
