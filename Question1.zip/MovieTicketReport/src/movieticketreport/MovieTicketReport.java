/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketreport;

/**
 *
 * @author Talha
 */
public class MovieTicketReport {
    public static void main(String[] args) {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] ticketSales = {
            {3000, 1500, 1700}, // Sales for Napoleon in Jan, Feb, Mar
            {3500, 1200, 1600}  // Sales for Oppenheimer in Jan, Feb, Mar
        };

        MovieTickets movieTickets = new MovieTickets();

        // Calculate total sales for each movie
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
        }

        // Print report
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("--------------------------------");
        System.out.printf("%-15s %-10s %-10s %-10s\n", "", "JAN", "FEB", "MAR");
        
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-15s %-10d %-10d %-10d\n", movies[i], ticketSales[i][0], ticketSales[i][1], ticketSales[i][2]);
        }

        // Print total sales for each movie
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("Total movie ticket sales for %s: %d\n", movies[i], totalSales[i]);
        }

        // Determine and print the top performing movie
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("Top performing movie: " + topMovie);
    }
}

//----Code Attribution----//
//(Movie Ticket Booking..)//
// Available at: ( https://youtube.com/playlist?list=PLQMGOpcYnHOV1u0J9OBVwvdQm79PIsbxi&si=wUVy-I2nKHt5zhPk )//
//Accessed on: 12 November 2024)//