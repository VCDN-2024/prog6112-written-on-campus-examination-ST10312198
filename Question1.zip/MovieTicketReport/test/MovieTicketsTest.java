/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Talha
 */
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        MovieTickets movieTickets = new MovieTickets();
        int[] ticketSales = {3000, 1500, 1700};
        int expectedTotal = 6200;
        assertEquals(expectedTotal, movieTickets.TotalMovieSales(ticketSales));
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        MovieTickets movieTickets = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};
        String expectedTopMovie = "Oppenheimer";
        assertEquals(expectedTopMovie, movieTickets.TopMovie(movies, totalSales));
    }
}

//Code Attribution//
//(Movie Ticket Booking System in Java part 1 problem statement explaination)//
//Available at:(https://youtu.be/mQLBX2dAgOM?si=uirCOx90oF5jM8w2) //
//Accessed on: (12 November 2024)//